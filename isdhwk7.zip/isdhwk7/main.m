[double_c,lenOfM]=LsbHide('carrier.bmp','information.txt','c_add_m.bmp',1.0);
LsbExtract('c_add_m.bmp',lenOfM,'extract.txt',1.0);

